Clazz.declarePackage ("J.api");
Clazz.load (["javajs.api.JmolObjectInterface"], "J.api.JmolToJSmolInterface", null, function () {
Clazz.declareInterface (J.api, "JmolToJSmolInterface", javajs.api.JmolObjectInterface);
});
